package com.example.screenrecorder

internal object RecorderPreferences {
    const val FILE_NAME = "screen_recorder_preferences"
    const val MICROPHONE_ENABLED = "microphone_enabled"
    const val HIDE_PANEL_DURING_RECORDING = "hide_panel_during_recording"
    const val OVERLAY_REQUESTED = "overlay_requested"
}
