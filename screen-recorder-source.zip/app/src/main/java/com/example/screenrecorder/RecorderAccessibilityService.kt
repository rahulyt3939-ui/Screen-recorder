package com.example.screenrecorder

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.os.Build
import android.view.KeyEvent
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class RecorderAccessibilityService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var microphoneButton: FrameLayout? = null
    private var microphoneIcon: TextView? = null
    private var primaryButton: FrameLayout? = null
    private var primaryIcon: TextView? = null
    private var endButton: FrameLayout? = null
    private var timerText: TextView? = null
    private var panelAttached = false
    private var receiverRegistered = false
    private var recordingState = RecorderService.STATE_IDLE
    private var microphoneIsOn = false
    private var elapsedMs = 0L
    private var frameRate = 60

    private val preferences by lazy {
        getSharedPreferences(RecorderPreferences.FILE_NAME, Context.MODE_PRIVATE)
    }

    private val panelReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_OVERLAY_COMMAND -> {
                    if (intent.getStringExtra(EXTRA_COMMAND) == COMMAND_SHOW) {
                        preferences.edit().putBoolean(RecorderPreferences.OVERLAY_REQUESTED, true).apply()
                        refreshPanelVisibility()
                    }
                }
                ACTION_OVERLAY_STATE -> {
                    recordingState = intent.getStringExtra(EXTRA_STATE) ?: RecorderService.STATE_IDLE
                    microphoneIsOn = intent.getBooleanExtra(EXTRA_MICROPHONE_ON, false)
                    elapsedMs = intent.getLongExtra(EXTRA_ELAPSED_MS, 0L)
                    frameRate = intent.getIntExtra(EXTRA_FRAME_RATE, 60)
                    refreshPanelVisibility()
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
        val filter = IntentFilter().apply {
            addAction(ACTION_OVERLAY_COMMAND)
            addAction(ACTION_OVERLAY_STATE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(panelReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(panelReceiver, filter)
        }
        receiverRegistered = true
        refreshPanelVisibility()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(panelReceiver)
            } catch (_: IllegalArgumentException) {
                // Android can unregister the receiver as part of service teardown.
            }
            receiverRegistered = false
        }
        removePanel()
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val action = when (event.keyCode) {
            KeyEvent.KEYCODE_F9 -> RecorderService.ACTION_KEY_F9
            KeyEvent.KEYCODE_F10 -> RecorderService.ACTION_STOP_RECORDING
            KeyEvent.KEYCODE_F11 -> RecorderService.ACTION_TOGGLE_MICROPHONE
            else -> return super.onKeyEvent(event)
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            dispatchRecorderAction(action)
        }
        return true
    }

    private fun dispatchRecorderAction(action: String) {
        try {
            if (action == RecorderService.ACTION_KEY_F9 &&
                recordingState == RecorderService.STATE_IDLE &&
                preferences.getBoolean(RecorderPreferences.HIDE_PANEL_DURING_RECORDING, true)
            ) {
                recordingState = RecorderService.STATE_STARTING
                refreshPanelVisibility()
            }
            startService(Intent(this, RecorderService::class.java).setAction(action))
        } catch (_: Exception) {
            recordingState = RecorderService.STATE_IDLE
            refreshPanelVisibility()
            Toast.makeText(this, "Open Screen Recorder once, then try the shortcut again.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshPanelVisibility() {
        val requested = preferences.getBoolean(RecorderPreferences.OVERLAY_REQUESTED, false)
        val hideDuringRecording = preferences.getBoolean(RecorderPreferences.HIDE_PANEL_DURING_RECORDING, true)
        val isRecordingOrStarting = recordingState != RecorderService.STATE_IDLE
        if (!requested || (hideDuringRecording && isRecordingOrStarting)) {
            removePanel()
            return
        }
        attachPanel()
        updatePanelContents()
    }

    private fun attachPanel() {
        if (panelAttached) return
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(3), dp(3), dp(4), dp(3))
                background = roundedBackground(Color.argb(232, 22, 31, 42))
            }

            val grip = TextView(this).apply {
                text = "⠿"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.LTGRAY)
                contentDescription = "Drag recorder panel"
                setOnTouchListener(createDragListener())
            }
            container.addView(grip, LinearLayout.LayoutParams(dp(20), dp(44)))

            val microphone = createControlButton("🎙", "Microphone on or off", Color.rgb(32, 120, 82)) {
                dispatchRecorderAction(RecorderService.ACTION_TOGGLE_MICROPHONE)
            }
            microphoneButton = microphone.first
            microphoneIcon = microphone.second
            container.addView(microphone.first, controlLayoutParams())

            val primary = createControlButton("▶", "Start, pause, or resume recording", Color.rgb(21, 101, 192)) {
                dispatchRecorderAction(RecorderService.ACTION_KEY_F9)
            }
            primaryButton = primary.first
            primaryIcon = primary.second
            container.addView(primary.first, controlLayoutParams())

            val end = createControlButton("■", "End and save recording", Color.rgb(176, 48, 48)) {
                dispatchRecorderAction(RecorderService.ACTION_STOP_RECORDING)
            }
            endButton = end.first
            container.addView(end.first, controlLayoutParams())

            val timer = TextView(this).apply {
                text = "00:00"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "Recording time"
            }
            timerText = timer
            container.addView(timer, LinearLayout.LayoutParams(dp(48), dp(48)))

            panel = container
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(24)
                y = dp(180)
            }
            panelParams = params
            windowManager?.addView(container, params)
            panelAttached = true
            updatePanelContents()
        } catch (_: Exception) {
            panelAttached = false
            Toast.makeText(this, "Recorder panel could not open. Use the notification or F9/F10/F11.", Toast.LENGTH_LONG).show()
        }
    }

    private fun createControlButton(
        glyph: String,
        description: String,
        color: Int,
        click: () -> Unit
    ): Pair<FrameLayout, TextView> {
        val icon = TextView(this).apply {
            text = glyph
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            contentDescription = description
            background = roundedBackground(color)
        }
        val button = FrameLayout(this).apply {
            isClickable = true
            isFocusable = false
            setOnClickListener { click() }
            minimumWidth = dp(48)
            minimumHeight = dp(48)
            addView(
                icon,
                FrameLayout.LayoutParams(
                    dp(20),
                    dp(20),
                    Gravity.CENTER
                )
            )
        }
        return button to icon
    }

    private fun controlLayoutParams() =
        LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            leftMargin = dp(2)
            rightMargin = dp(2)
        }

    private fun createDragListener(): android.view.View.OnTouchListener {
        var downX = 0f
        var downY = 0f
        var originX = 0
        var originY = 0
        var moved = false
        return android.view.View.OnTouchListener { _, event ->
            val params = panelParams
            if (params == null) {
                false
            } else {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        originX = params.x
                        originY = params.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(4)) moved = true
                        if (moved) {
                            params.x = (originX + dx).coerceAtLeast(0)
                            params.y = (originY + dy).coerceAtLeast(0)
                            try {
                                panel?.let { currentPanel -> windowManager?.updateViewLayout(currentPanel, params) }
                            } catch (_: Exception) {
                                // Ignore movement if Android has removed the accessibility overlay.
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
    }

    private fun updatePanelContents() {
        if (!panelAttached) return
        val micOn = if (recordingState == RecorderService.STATE_RECORDING ||
            recordingState == RecorderService.STATE_PAUSED
        ) {
            microphoneIsOn
        } else {
            preferences.getBoolean(RecorderPreferences.MICROPHONE_ENABLED, true) &&
                checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        microphoneIcon?.text = if (micOn) "🎙" else "🔇"
        microphoneButton?.contentDescription = if (micOn) "Turn microphone off" else "Turn microphone on"

        val (primaryGlyph, primaryDescription) = when (recordingState) {
            RecorderService.STATE_RECORDING -> "Ⅱ" to "Pause recording"
            RecorderService.STATE_PAUSED -> "▶" to "Resume recording"
            RecorderService.STATE_STARTING -> "…" to "Recording is starting"
            RecorderService.STATE_STOPPING -> "…" to "Saving recording"
            else -> "▶" to "Start recording"
        }
        primaryIcon?.text = primaryGlyph
        primaryButton?.contentDescription = primaryDescription
        endButton?.contentDescription = "End and save recording"
        timerText?.text = formatTime(elapsedMs)
    }

    private fun removePanel() {
        val current = panel ?: return
        if (panelAttached) {
            try {
                windowManager?.removeView(current)
            } catch (_: Exception) {
                // Android may already have detached the accessibility overlay.
            }
        }
        panelAttached = false
        panel = null
        panelParams = null
        microphoneButton = null
        microphoneIcon = null
        primaryButton = null
        primaryIcon = null
        endButton = null
        timerText = null
    }

    private fun roundedBackground(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(8).toFloat()
        setColor(color)
    }

    private fun formatTime(milliseconds: Long): String {
        val totalSeconds = (milliseconds / 1_000L).coerceAtLeast(0L)
        val seconds = totalSeconds % 60L
        val minutes = (totalSeconds / 60L) % 60L
        val hours = totalSeconds / 3_600L
        return if (hours > 0) {
            String.format(java.util.Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", totalSeconds / 60L, seconds)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val ACTION_OVERLAY_COMMAND = "com.example.screenrecorder.OVERLAY_COMMAND"
        const val ACTION_OVERLAY_STATE = "com.example.screenrecorder.OVERLAY_STATE"
        const val EXTRA_COMMAND = "overlay_command"
        const val EXTRA_STATE = "state"
        const val EXTRA_MICROPHONE_ON = "microphone_on"
        const val EXTRA_ELAPSED_MS = "elapsed_ms"
        const val EXTRA_FRAME_RATE = "frame_rate"
        const val COMMAND_SHOW = "show"
    }
}
