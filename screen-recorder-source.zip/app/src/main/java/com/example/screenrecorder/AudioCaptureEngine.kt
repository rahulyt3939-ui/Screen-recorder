package com.example.screenrecorder

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Process
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue

/**
 * Captures permitted playback audio and microphone audio, mixes them to mono PCM,
 * and writes an AAC track in a temporary MP4 container for final muxing.
 */
internal class AudioCaptureEngine private constructor(
    private val playback: Source?,
    private val microphone: Source?,
    private val outputFile: File,
    microphoneInitiallyEnabled: Boolean
) {
    private data class Source(
        val recorder: AudioRecord,
        val frames: ArrayBlockingQueue<ShortArray>
    )

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile var microphoneEnabled = microphone != null && microphoneInitiallyEnabled
        private set
    val microphoneAvailable: Boolean
        get() = microphone != null

    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var audioTrack = -1
    private var muxerStarted = false
    private var captureThread: Thread? = null
    private val readerThreads = mutableListOf<Thread>()
    private val activeSources = mutableListOf<Source>()
    private var submittedSamples = 0L

    fun start() {
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1)
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        format.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, FRAME_SAMPLES * 2)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val audioMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        codec = encoder
        muxer = audioMuxer
        running = true
        try {
            encoder.start()
            startSource(playback, "PlaybackAudio")
            if (microphoneEnabled) startSource(microphone, "MicrophoneAudio")
            captureThread = Thread({ encodeMixedAudio() }, "ScreenRecorder-AAC")
            captureThread?.start()
        } catch (error: Exception) {
            running = false
            release()
            throw error
        }
    }

    fun setPaused(value: Boolean) {
        if (!running || paused == value) return
        paused = value
        if (value) {
            activeSources.toList().forEach { source ->
                try {
                    source.recorder.stop()
                } catch (_: IllegalStateException) {
                    // A failed or already stopped recorder needs no further action.
                }
                source.frames.clear()
            }
        } else {
            activeSources
                .filterNot { source -> source === microphone && !microphoneEnabled }
                .forEach { source ->
                    source.frames.clear()
                    try {
                        source.recorder.startRecording()
                    } catch (_: IllegalStateException) {
                        if (source === microphone) microphoneEnabled = false
                    }
                }
        }
    }

    fun toggleMicrophone(): Boolean {
        val source = microphone ?: return false
        if (!running) return false
        val nextState = !microphoneEnabled
        source.frames.clear()
        if (paused) {
            microphoneEnabled = nextState
            if (nextState && !activeSources.contains(source)) {
                activeSources.add(source)
                val reader = Thread({ readSource(source) }, "MicrophoneAudio")
                readerThreads.add(reader)
                reader.start()
            }
            return microphoneEnabled
        }
        return try {
            if (nextState) {
                source.recorder.startRecording()
                if (!activeSources.contains(source)) {
                    activeSources.add(source)
                    val reader = Thread({ readSource(source) }, "MicrophoneAudio")
                    readerThreads.add(reader)
                    reader.start()
                }
            } else {
                source.recorder.stop()
            }
            microphoneEnabled = nextState
            microphoneEnabled
        } catch (_: Exception) {
            microphoneEnabled = false
            false
        }
    }

    fun stop() {
        if (!running) return
        running = false
        paused = false
        activeSources.toList().forEach { source ->
            try {
                source.recorder.stop()
            } catch (_: IllegalStateException) {
                // The reader thread will exit after the stop signal.
            }
        }
        readerThreads.forEach { it.join(1_000) }
        captureThread?.join(10_000)
        release()
    }

    private fun readSource(source: Source) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        while (running) {
            if (paused || (source === microphone && !microphoneEnabled)) {
                try {
                    Thread.sleep(15)
                } catch (_: InterruptedException) {
                    return
                }
                continue
            }
            val frame = ShortArray(FRAME_SAMPLES)
            val count = try {
                source.recorder.read(frame, 0, frame.size, AudioRecord.READ_BLOCKING)
            } catch (_: IllegalStateException) {
                -1
            }
            if (count > 0 && running && !paused) {
                val readyFrame = if (count == frame.size) frame else frame.copyOf(count)
                if (!source.frames.offer(readyFrame)) {
                    source.frames.poll()
                    source.frames.offer(readyFrame)
                }
            } else if (count < 0 && running && !paused) {
                try {
                    Thread.sleep(20)
                } catch (_: InterruptedException) {
                    return
                }
            }
        }
    }

    private fun startSource(source: Source?, threadName: String) {
        if (source == null) return
        try {
            source.recorder.startRecording()
            activeSources.add(source)
            val reader = Thread({ readSource(source) }, threadName)
            readerThreads.add(reader)
            reader.start()
        } catch (_: Exception) {
            if (source === microphone) microphoneEnabled = false
        }
    }

    private fun encodeMixedAudio() {
        val encoder = codec ?: return
        val info = MediaCodec.BufferInfo()
        var nextFrameTimeNs = System.nanoTime()
        while (running) {
            if (paused) {
                drainEncoder(encoder, info, false)
                try {
                    Thread.sleep(10)
                } catch (_: InterruptedException) {
                    break
                }
                nextFrameTimeNs = System.nanoTime()
                continue
            }

            val waitNs = nextFrameTimeNs - System.nanoTime()
            if (waitNs > 0L) {
                try {
                    Thread.sleep(waitNs / 1_000_000L, (waitNs % 1_000_000L).toInt())
                } catch (_: InterruptedException) {
                    break
                }
            }

            val playbackFrame = playback?.frames?.poll()
            val micFrame = microphone?.frames?.poll()
            val pcm = ShortArray(FRAME_SAMPLES)
            for (index in pcm.indices) {
                val gameSample = playbackFrame?.getOrZero(index) ?: 0
                val micSample = if (microphoneEnabled) micFrame?.getOrZero(index) ?: 0 else 0
                pcm[index] = (gameSample + micSample).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            if (!paused && running) submitPcm(encoder, pcm, info)
            nextFrameTimeNs += FRAME_DURATION_NS
            val now = System.nanoTime()
            if (nextFrameTimeNs < now - FRAME_DURATION_NS) {
                nextFrameTimeNs = now
            }
            drainEncoder(encoder, info, false)
        }

        var eosQueued = false
        var eosReceived = false
        while (!eosReceived) {
            if (!eosQueued) {
                val inputIndex = encoder.dequeueInputBuffer(10_000)
                if (inputIndex >= 0) {
                    encoder.queueInputBuffer(
                        inputIndex,
                        0,
                        0,
                        submittedSamples * 1_000_000L / SAMPLE_RATE,
                        MediaCodec.BUFFER_FLAG_END_OF_STREAM
                    )
                    eosQueued = true
                }
            }
            eosReceived = drainEncoder(encoder, info, true)
        }
    }

    private fun submitPcm(encoder: MediaCodec, pcm: ShortArray, info: MediaCodec.BufferInfo) {
        val inputIndex = encoder.dequeueInputBuffer(10_000)
        if (inputIndex >= 0) {
            val buffer = encoder.getInputBuffer(inputIndex)
            if (buffer != null) {
                buffer.clear()
                val count = minOf(pcm.size, buffer.remaining() / 2)
                for (index in 0 until count) buffer.putShort(pcm[index])
                val pts = submittedSamples * 1_000_000L / SAMPLE_RATE
                encoder.queueInputBuffer(inputIndex, 0, count * 2, pts, 0)
                submittedSamples += count
            } else {
                encoder.queueInputBuffer(inputIndex, 0, 0, 0, 0)
            }
        }
        drainEncoder(encoder, info, false)
    }

    private fun drainEncoder(
        encoder: MediaCodec,
        info: MediaCodec.BufferInfo,
        endOfStream: Boolean
    ): Boolean {
        while (true) {
            val outputIndex = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
            when {
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (muxerStarted) throw IllegalStateException("AAC encoder changed format after starting the muxer.")
                    audioTrack = muxer!!.addTrack(encoder.outputFormat)
                    muxer!!.start()
                    muxerStarted = true
                }
                outputIndex >= 0 -> {
                    val outputBuffer = encoder.getOutputBuffer(outputIndex)
                    if (outputBuffer != null && info.size > 0 && muxerStarted) {
                        outputBuffer.position(info.offset)
                        outputBuffer.limit(info.offset + info.size)
                        muxer!!.writeSampleData(audioTrack, outputBuffer, info)
                    }
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    encoder.releaseOutputBuffer(outputIndex, false)
                    if (eos) return true
                }
            }
        }
    }

    private fun release() {
        try {
            codec?.stop()
        } catch (_: IllegalStateException) {
            // Encoder may not have reached its started state.
        }
        codec?.release()
        codec = null
        try {
            if (muxerStarted) muxer?.stop()
        } catch (_: IllegalStateException) {
            // Discard an incomplete AAC container during failure cleanup.
        }
        muxer?.release()
        muxer = null
        listOfNotNull(playback, microphone).forEach { it.recorder.release() }
    }

    private fun ShortArray.getOrZero(index: Int): Int = getOrNull(index)?.toInt() ?: 0

    companion object {
        private const val SAMPLE_RATE = 48_000
        private const val FRAME_SAMPLES = 1_024
        private const val FRAME_DURATION_NS = FRAME_SAMPLES * 1_000_000_000L / SAMPLE_RATE

        fun create(
            context: Context,
            projection: MediaProjection,
            outputFile: File,
            microphoneInitiallyEnabled: Boolean = true
        ): AudioCaptureEngine? {
            val minBytes = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).let { if (it > 0) maxOf(it, FRAME_SAMPLES * 4) else FRAME_SAMPLES * 4 }

            val playbackSource = if (Build.VERSION.SDK_INT >= 29) {
                try {
                    val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()
                    val playbackFormat = AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                    val recorder = AudioRecord.Builder()
                        .setAudioFormat(playbackFormat)
                        .setBufferSizeInBytes(minBytes)
                        .setAudioPlaybackCaptureConfig(captureConfig)
                        .build()
                    if (recorder.state == AudioRecord.STATE_INITIALIZED) Source(recorder, ArrayBlockingQueue(8))
                    else {
                        recorder.release()
                        null
                    }
                } catch (_: Exception) {
                    null
                }
            } else null

            val microphoneSource = if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                try {
                    val recorder = AudioRecord.Builder()
                        .setAudioSource(android.media.MediaRecorder.AudioSource.MIC)
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(minBytes)
                        .build()
                    if (recorder.state == AudioRecord.STATE_INITIALIZED) Source(recorder, ArrayBlockingQueue(8))
                    else {
                        recorder.release()
                        null
                    }
                } catch (_: Exception) {
                    null
                }
            } else null

            if (playbackSource == null && microphoneSource == null) return null
            return AudioCaptureEngine(
                playbackSource,
                microphoneSource,
                outputFile,
                microphoneInitiallyEnabled
            )
        }
    }
}
