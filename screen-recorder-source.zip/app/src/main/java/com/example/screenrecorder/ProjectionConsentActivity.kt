package com.example.screenrecorder

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle

class ProjectionConsentActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("MediaProjection consent is returned through the activity result API.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) {
            finish()
            return
        }

        if (resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, RecorderService::class.java)
                .setAction(RecorderService.ACTION_PROJECTION_GRANTED)
                .putExtra(RecorderService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(RecorderService.EXTRA_RESULT_DATA, data)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PROJECTION_CANCELLED))
        }
        finish()
    }

    companion object {
        private const val REQUEST_CAPTURE = 401
    }
}
