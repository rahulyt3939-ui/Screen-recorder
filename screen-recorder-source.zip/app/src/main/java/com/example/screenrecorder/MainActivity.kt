package com.example.screenrecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.permissionStatus)

        findViewById<Button>(R.id.overlayPermissionButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } else {
                showMessage("Overlay permission is already granted.")
            }
        }

        findViewById<Button>(R.id.microphonePermissionButton).setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                showMessage("Microphone permission is already granted.")
            } else {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
            }
        }

        findViewById<Button>(R.id.notificationPermissionButton).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            } else {
                showMessage("Notification permission is not needed on this Android version, or is already granted.")
            }
        }

        findViewById<Button>(R.id.accessibilityPermissionButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.startFloatingRecorderButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                showMessage("Grant Overlay Permission before starting the floating recorder.")
                return@setOnClickListener
            }
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_SHOW_OVERLAY))
            showMessage("Floating recorder started. Tap Start on the floating button to begin.")
        }
        refreshPermissionStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshPermissionStatus()
    }

    @Deprecated("Kept for compatibility with the minimum supported Android version.")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MICROPHONE || requestCode == REQUEST_NOTIFICATIONS) {
            refreshPermissionStatus()
            showMessage(if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                "Permission granted."
            } else {
                "Permission was not granted. Video recording can still work without that permission."
            })
        }
    }

    private fun refreshPermissionStatus() {
        val accessibilityManager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val keyboardServiceEnabled = accessibilityManager
            .getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == RecorderAccessibilityService::class.java.name }

        val microphone = if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) "granted" else "not granted"
        val overlay = if (Settings.canDrawOverlays(this)) "granted" else "not granted"
        val accessibility = if (keyboardServiceEnabled) "enabled" else "not enabled"
        val notifications = if (Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) "available" else "not granted"

        status.text = "Overlay: $overlay\nMicrophone: $microphone\nNotifications: $notifications\nKeyboard controls: $accessibility"
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val REQUEST_MICROPHONE = 101
        private const val REQUEST_NOTIFICATIONS = 102
    }
}
