# Screen Recorder — Android project

Yeh native Kotlin app Android 10+ ke liye hai. Is folder ke andar diye gaye files ka exact path project root se relative hai. GitHub Actions debug APK banata hai.

## Phone se GitHub par build karne ke steps

1. Replit se `screen-recorder-source.zip` apne phone par download karein.
2. Phone browser mein `github.com` kholkar sign in karein aur **New repository** se ek repository banayein. Public ya private, dono chalenge.
3. Repository mein **Add file → Upload files** chunein, `screen-recorder-source.zip` upload karein, aur **Commit changes** karein.
4. **Add file → Create new file** chunein. File name mein yeh poora path dalein: `.github/workflows/build.yml`
5. Neeche diye gaye GitHub Actions YAML ko paste karke **Commit changes** karein. Workflow archive se Android files nikaal kar APK banayega.
6. Repository ka **Actions** tab kholein, **Build debug APK** workflow run select karein, aur job complete hone ka intezar karein.
7. Run page ke **Artifacts** section mein `screen-recorder-debug-apk` download karein. ZIP ko Files app se extract karke `app-debug.apk` par tap karein.
8. Android agar kahe, to browser/Files app ke liye **Install unknown apps** allow karein, phir APK install karein.

## Permission aur control setup

1. App kholkar **Grant Overlay Permission** dabayein aur Screen Recorder ko allow karein.
2. **Grant Microphone Permission** dabayein. Is permission se mic aur Android ki allowed playback/game audio capture dono kaam kar sakte hain.
3. **Grant Notification Permission** dabayein (Android 13+ par prompt aayega).
4. **Enable Keyboard Controls** dabakar Android Accessibility settings mein **Screen Recorder Keyboard Controls** enable karein.
5. App par wapas aakar **Start Floating Recorder** dabayein. Game mein jaakar overlay ka **Start** dabayein, phir Android ke screen-capture confirmation ko approve karein.
6. Recording ke dauran overlay **Pause** / **Resume** aur **Stop** dikhata hai. **F9** start/pause/resume, **F10** stop, aur **F11** mic audio ko on/off karta hai.

## Recording behavior aur Android restrictions

- Video H.264 MP4 mein 1080p aur 16 Mbps target bitrate se record hota hai. Device ke encoder capabilities ke hisaab se frame rate 60 ya 30 fps set hota hai.
- Overlay window par `FLAG_SECURE` laga hai, taaki floating controls recording mein capture na hon. Is flag ke kaaran doosre screen-capture tools overlay ko black/hidden dikha sakte hain.
- Internal/game audio Android 10+ par `AudioPlaybackCapture` se liya jata hai. Har game/app capture allow nahi karta; aise mein us app ka audio nahi aayega.
- Android har recording session ke liye screen-capture consent mangta hai. App system prompt ko bypass nahi karti.
- F11 mute karne par mic samples file mein nahi bheje jaate aur mic recorder pause hota hai. Device par app microphone foreground-service type mein rahegi, kyunki recording chalu rehti hai.
- Completed recordings `Movies/ScreenRec/ScreenRec_YYYYMMDD_HHMMSS.mp4` mein save hoti hain.

## Project files

```text
settings.gradle.kts
build.gradle.kts
gradle.properties
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/example/screenrecorder/MainActivity.kt
app/src/main/java/com/example/screenrecorder/ProjectionConsentActivity.kt
app/src/main/java/com/example/screenrecorder/RecorderService.kt
app/src/main/java/com/example/screenrecorder/RecorderAccessibilityService.kt
app/src/main/java/com/example/screenrecorder/AudioCaptureEngine.kt
app/src/main/res/layout/activity_main.xml
app/src/main/res/values/strings.xml
app/src/main/res/values/styles.xml
app/src/main/res/xml/accessibility_service_config.xml
app/src/main/res/drawable/ic_notification.xml
.github/workflows/build.yml
```
