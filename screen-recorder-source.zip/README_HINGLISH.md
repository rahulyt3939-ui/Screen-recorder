# Screen Recorder — Android project

Yeh native Kotlin app Android 10+ (minSdk 29) ke liye hai. Is folder ke andar ke paths project root se relative hain. GitHub Actions debug APK banata hai.

## GitHub se phone par APK banana

1. Replit se `screen-recorder-source.zip` phone par download karein.
2. `github.com` mein repository banayein, jaise `screen-recorder`.
3. Repository mein **Add file → Upload files** dabakar `screen-recorder-source.zip` upload aur commit karein.
4. **Add file → Create new file** chunein. File path exact yeh ho: `.github/workflows/build.yml`. ZIP ke andar wali copy GitHub Actions ko nahi chalati—workflow file repository mein alag se honi chahiye.
5. Root `.github/workflows/build.yml` mein diye gaye Actions code ko paste karke commit karein. GitHub repository ke **Actions** tab mein **Build debug APK** run khulega.
6. Successful run par **Artifacts** se `screen-recorder-debug-apk` download karein. ZIP extract karke `app-debug.apk` install karein. Zaroorat par Files/browser ke liye **Install unknown apps** allow karein.

## Permissions aur use

1. App mein **Grant Overlay Permission**, **Grant Microphone Permission**, **Grant Notification Permission** dabayein.
2. **Enable Keyboard Controls** dabakar Accessibility settings mein **Screen Recorder Keyboard Controls** enable karein; app par wapas aayein.
3. **Hide panel while recording** default se checked hai. Isse recording start hote hi panel hide hota hai, isliye video mein panel ya black box nahi aata. Hide kiye bina panel dekhne ke liye checkbox off karein; kuch phones par FLAG_SECURE panel capture se bachane ke bajaye black area dikha sakta hai.
4. **Start Floating Recorder** dabayein. Panel se Mic, Start/Pause/Resume, End aur timer use karein. Panel ko uske dotted grip se drag karein.
5. Shortcuts: **F9** start/pause/resume, **F10** end, **F11** mic on/off. Recording panel hidden hone par notification mein bhi Mic, Start/Pause/Resume aur End buttons hain.

## Recording details

- MediaProjection se portrait/landscape 1080p H.264 MP4, 16 Mbps target par record hota hai. 60 fps support na ho to 30 fps use karke short toast dikhata hai.
- Mic mute karne par video/audio recording nahi rukti; mic ka mix mute rehta hai aur AAC audio track ko audio/video MP4 mein mux kiya jata hai.
- Internal/game audio Android 10+ playback capture se aata hai jab game capture allow karta hai. Har game allow nahi karta.
- Timer pause par rukta hai, elapsed recording time dikhata hai, aur End save hone ke baad zero ho jata hai. Android har session mein screen-capture confirmation dikhata hai.
- Recordings `Movies/ScreenRec/ScreenRec_YYYYMMDD_HHMMSS.mp4` mein save hoti hain.

## Exact source paths

```text
settings.gradle.kts
build.gradle.kts
gradle.properties
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/example/screenrecorder/MainActivity.kt
app/src/main/java/com/example/screenrecorder/ProjectionConsentActivity.kt
app/src/main/java/com/example/screenrecorder/RecorderService.kt
app/src/main/java/com/example/screenrecorder/RecorderAccessibilityService.kt
app/src/main/java/com/example/screenrecorder/RecorderPreferences.kt
app/src/main/java/com/example/screenrecorder/AudioCaptureEngine.kt
app/src/main/res/layout/activity_main.xml
app/src/main/res/values/strings.xml
app/src/main/res/values/styles.xml
app/src/main/res/xml/accessibility_service_config.xml
app/src/main/res/drawable/ic_notification.xml
.github/workflows/build.yml
```
