package com.example.screenrecorder

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecorderService : Service() {
    private enum class RecordingState { IDLE, STARTING, RECORDING, PAUSED, STOPPING }

    private var state = RecordingState.IDLE
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var primaryButton: Button? = null
    private var stopButton: Button? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var overlayAttached = false
    private var recorder: MediaRecorder? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var audioCapture: AudioCaptureEngine? = null
    private var videoTempFile: File? = null
    private var audioTempFile: File? = null
    private var selectedFrameRate = 60
    private var micGrantedAtStart = false
    private var notificationActive = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        attachOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent ?: return START_NOT_STICKY
        when (command.action) {
            ACTION_SHOW_OVERLAY -> attachOverlay()
            ACTION_START_RECORDING -> requestProjectionConsent()
            ACTION_PROJECTION_GRANTED -> {
                val resultCode = command.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = if (Build.VERSION.SDK_INT >= 33) {
                    command.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    command.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    beginRecording(resultCode, resultData)
                } else {
                    state = RecordingState.IDLE
                    updateOverlay()
                }
            }
            ACTION_PROJECTION_CANCELLED -> {
                if (state == RecordingState.STARTING) {
                    state = RecordingState.IDLE
                    updateOverlay()
                }
            }
            ACTION_KEY_F9 -> when (state) {
                RecordingState.IDLE -> requestProjectionConsent()
                RecordingState.RECORDING -> pauseRecording()
                RecordingState.PAUSED -> resumeRecording()
                else -> Unit
            }
            ACTION_PAUSE_RECORDING -> pauseRecording()
            ACTION_RESUME_RECORDING -> resumeRecording()
            ACTION_STOP_RECORDING -> stopRecording()
            ACTION_TOGGLE_MICROPHONE -> toggleMicrophone()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopRecording()
        removeOverlay()
        super.onDestroy()
    }

    private fun requestProjectionConsent() {
        if (state != RecordingState.IDLE) return
        state = RecordingState.STARTING
        updateOverlay()
        try {
            startActivity(
                Intent(this, ProjectionConsentActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            state = RecordingState.IDLE
            updateOverlay()
            Toast.makeText(this, "Open Screen Recorder first, then tap Start again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun beginRecording(resultCode: Int, resultData: Intent) {
        if (state == RecordingState.STOPPING) return
        state = RecordingState.STARTING
        val hasMicrophonePermission = checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        micGrantedAtStart = hasMicrophonePermission
        try {
            startAsForegroundService(hasMicrophonePermission)
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val activeProjection = manager.getMediaProjection(resultCode, resultData)
                ?: throw IllegalStateException("Android did not provide screen-capture access.")
            projection = activeProjection

            val displaySize = recordingSize()
            selectedFrameRate = supportedFrameRate(displaySize.first, displaySize.second)
            val cache = File(cacheDir, "screenrecorder").apply { mkdirs() }
            videoTempFile = File(cache, "video_${System.currentTimeMillis()}.mp4")
            audioTempFile = File(cache, "audio_${System.currentTimeMillis()}.m4a")

            val videoRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder = videoRecorder
            videoRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            videoRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            videoRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            videoRecorder.setVideoEncodingBitRate(VIDEO_BIT_RATE)
            videoRecorder.setVideoFrameRate(selectedFrameRate)
            videoRecorder.setVideoSize(displaySize.first, displaySize.second)
            videoRecorder.setOutputFile(videoTempFile!!.absolutePath)
            videoRecorder.prepare()

            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() {
                    val stoppedProjection = projection
                    projection = null
                    if (state != RecordingState.IDLE && state != RecordingState.STOPPING) {
                        stopRecording(stopProjection = false)
                    }
                    stoppedProjection?.let {
                        try {
                            it.unregisterCallback(this)
                        } catch (_: Exception) {
                            // The platform may already have removed the callback.
                        }
                    }
                }
            }
            activeProjection.registerCallback(projectionCallback!!, Handler(Looper.getMainLooper()))

            val density = resources.displayMetrics.densityDpi
            virtualDisplay = activeProjection.createVirtualDisplay(
                "ScreenRecorderDisplay",
                displaySize.first,
                displaySize.second,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR or DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
                videoRecorder.surface,
                null,
                Handler(Looper.getMainLooper())
            ) ?: throw IllegalStateException("Android could not create the recording display.")

            videoRecorder.start()

            audioCapture = try {
                AudioCaptureEngine.create(this, activeProjection, audioTempFile!!)?.also { it.start() }
            } catch (_: Exception) {
                null
            }

            state = RecordingState.RECORDING
            updateOverlay()
            updateNotification()
        } catch (error: Exception) {
            cleanupFailedStart()
            state = RecordingState.IDLE
            updateOverlay()
            stopForegroundIfActive()
            Toast.makeText(this, error.message ?: "Recording could not start on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startAsForegroundService(includeMicrophone: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (includeMicrophone) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIFICATION_ID, buildNotification(), type)
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        notificationActive = true
    }

    private fun recordingSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        return if (metrics.widthPixels >= metrics.heightPixels) {
            Pair(1920, 1080)
        } else {
            Pair(1080, 1920)
        }
    }

    private fun supportedFrameRate(width: Int, height: Int): Int {
        val canEncode = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { codec ->
            if (!codec.isEncoder) return@any false
            try {
                val capabilities = codec.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
                capabilities.videoCapabilities.areSizeAndRateSupported(width, height, 60.0)
            } catch (_: Exception) {
                false
            }
        }
        return if (canEncode) 60 else 30
    }

    private fun pauseRecording() {
        if (state != RecordingState.RECORDING) return
        try {
            recorder?.pause()
            audioCapture?.setPaused(true)
            state = RecordingState.PAUSED
            updateOverlay()
            updateNotification()
        } catch (_: Exception) {
            Toast.makeText(this, "Pause is not available on this device.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resumeRecording() {
        if (state != RecordingState.PAUSED) return
        try {
            recorder?.resume()
            audioCapture?.setPaused(false)
            state = RecordingState.RECORDING
            updateOverlay()
            updateNotification()
        } catch (_: Exception) {
            Toast.makeText(this, "Recording could not resume.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleMicrophone() {
        val capture = audioCapture
        if (capture == null || !micGrantedAtStart) {
            Toast.makeText(this, "Grant microphone permission before recording to use F11.", Toast.LENGTH_SHORT).show()
            return
        }
        val enabled = capture.toggleMicrophone()
        updateNotification()
        Toast.makeText(this, if (enabled) "Microphone audio on." else "Microphone audio off.", Toast.LENGTH_SHORT).show()
    }

    private fun stopRecording(stopProjection: Boolean = true) {
        if (state == RecordingState.IDLE || state == RecordingState.STOPPING) return
        state = RecordingState.STOPPING
        updateOverlay()

        val audioToStop = audioCapture
        audioCapture = null
        val recorderToStop = recorder
        recorder = null
        val displayToRelease = virtualDisplay
        virtualDisplay = null
        val projectionToStop = projection
        projection = null
        val callbackToRemove = projectionCallback
        projectionCallback = null

        val videoFile = videoTempFile
        val audioFile = audioTempFile
        videoTempFile = null
        audioTempFile = null

        Thread({
            var saved: Uri? = null
            try {
                try {
                    audioToStop?.stop()
                } catch (_: Exception) {
                    // Keep the completed video even if the optional audio track did not finish.
                }

                var videoIsUsable = false
                try {
                    recorderToStop?.stop()
                    videoIsUsable = videoFile?.exists() == true && videoFile.length() > 0
                } catch (_: Exception) {
                    // MediaRecorder.stop() can fail when it has not produced a valid frame.
                }
                try {
                    recorderToStop?.reset()
                } catch (_: Exception) {
                    // The recorder may already have stopped after a device error.
                }
                try {
                    recorderToStop?.release()
                } catch (_: Exception) {
                    // Release failure does not prevent attempting to save the encoded file.
                }
                try {
                    displayToRelease?.release()
                } catch (_: Exception) {
                    // The virtual display may have been removed by Android.
                }

                if (projectionToStop != null) {
                    try {
                        callbackToRemove?.let(projectionToStop::unregisterCallback)
                    } catch (_: Exception) {
                        // It may have been stopped by Android already.
                    }
                    if (stopProjection) {
                        try {
                            projectionToStop.stop()
                        } catch (_: Exception) {
                            // Projection is already stopped.
                        }
                    }
                }
                if (videoIsUsable && videoFile != null) {
                    saved = try {
                        saveRecording(videoFile, audioFile)
                    } catch (_: Exception) {
                        null
                    }
                }
            } catch (_: Exception) {
                // Finalization errors should still release the foreground notification and temp files.
            } finally {
                videoFile?.delete()
                audioFile?.delete()
                mainHandler.post {
                    state = RecordingState.IDLE
                    updateOverlay()
                    if (saved != null) {
                        Toast.makeText(this, "Saved to Movies/ScreenRec.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "No video was saved. Try recording again.", Toast.LENGTH_LONG).show()
                    }
                    stopForegroundIfActive()
                }
            }
        }, "ScreenRecorder-Finalize").start()
    }

    private fun saveRecording(videoFile: File, audioFile: File?): Uri? {
        val validAudioFile = audioFile?.takeIf { it.exists() && it.length() > 0 }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "ScreenRec_$timestamp.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/ScreenRec")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null

        try {
            contentResolver.openFileDescriptor(outputUri, "w").use { descriptor ->
                if (descriptor == null) throw IllegalStateException("Could not open the Movies folder.")
                muxTracks(videoFile, validAudioFile, descriptor.fileDescriptor)
            }
            val published = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(outputUri, published, null, null)
            return outputUri
        } catch (_: Exception) {
            try {
                contentResolver.delete(outputUri, null, null)
            } catch (_: Exception) {
                // The pending item will not be presented as a completed recording.
            }
            val fallback = insertVideoOnly(name, videoFile)
            return fallback
        }
    }

    private fun muxTracks(videoFile: File, audioFile: File?, destination: java.io.FileDescriptor) {
        val videoExtractor = android.media.MediaExtractor()
        val audioExtractor = android.media.MediaExtractor()
        var muxer: android.media.MediaMuxer? = null
        var started = false
        try {
            videoExtractor.setDataSource(videoFile.absolutePath)
            val videoTrack = findTrack(videoExtractor, "video/")
                ?: throw IllegalStateException("The video file has no video track.")
            val audioTrack = if (audioFile != null) {
                try {
                    audioExtractor.setDataSource(audioFile.absolutePath)
                    findTrack(audioExtractor, "audio/")
                } catch (_: Exception) {
                    null
                }
            } else null

            muxer = android.media.MediaMuxer(destination, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outputVideoTrack = muxer.addTrack(videoExtractor.getTrackFormat(videoTrack))
            val outputAudioTrack = audioTrack?.let { muxer.addTrack(audioExtractor.getTrackFormat(it)) }
            muxer.start()
            started = true
            copySamples(videoExtractor, videoTrack, outputVideoTrack, muxer)
            if (audioTrack != null && outputAudioTrack != null) {
                copySamples(audioExtractor, audioTrack, outputAudioTrack, muxer)
            }
            muxer.stop()
            started = false
        } finally {
            if (started) {
                try {
                    muxer?.stop()
                } catch (_: Exception) {
                    // Remove the incomplete output and retry as video-only.
                }
            }
            muxer?.release()
            videoExtractor.release()
            audioExtractor.release()
        }
    }

    private fun findTrack(extractor: android.media.MediaExtractor, mimePrefix: String): Int? {
        for (index in 0 until extractor.trackCount) {
            if (extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith(mimePrefix) == true) {
                return index
            }
        }
        return null
    }

    private fun copySamples(
        extractor: android.media.MediaExtractor,
        sourceTrack: Int,
        destinationTrack: Int,
        muxer: android.media.MediaMuxer
    ) {
        extractor.selectTrack(sourceTrack)
        val format = extractor.getTrackFormat(sourceTrack)
        val capacity = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
            maxOf(format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE), 256 * 1024)
        } else {
            2 * 1024 * 1024
        }
        val buffer = ByteBuffer.allocateDirect(capacity)
        val info = MediaCodecBufferInfo()
        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            info.set(size, extractor.sampleTime, extractor.sampleFlags)
            buffer.position(0)
            buffer.limit(size)
            muxer.writeSampleData(destinationTrack, buffer, info.asPlatformInfo())
            if (!extractor.advance()) break
        }
        extractor.unselectTrack(sourceTrack)
    }

    private data class MediaCodecBufferInfo(
        var size: Int = 0,
        var presentationTimeUs: Long = 0,
        var flags: Int = 0
    ) {
        fun set(sampleSize: Int, sampleTimeUs: Long, sampleFlags: Int) {
            size = sampleSize
            presentationTimeUs = sampleTimeUs
            flags = sampleFlags
        }

        fun asPlatformInfo(): android.media.MediaCodec.BufferInfo =
            android.media.MediaCodec.BufferInfo().apply {
                set(
                    0,
                    this@MediaCodecBufferInfo.size,
                    this@MediaCodecBufferInfo.presentationTimeUs,
                    this@MediaCodecBufferInfo.flags
                )
            }
    }

    private fun insertVideoOnly(name: String, videoFile: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/ScreenRec")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            contentResolver.openOutputStream(uri, "w").use { output ->
                if (output == null) throw IllegalStateException("Could not open the output video.")
                FileInputStream(videoFile).use { input -> input.copyTo(output) }
            }
            contentResolver.update(
                uri,
                ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) },
                null,
                null
            )
            uri
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun cleanupFailedStart() {
        try {
            audioCapture?.stop()
        } catch (_: Exception) {
            // Best-effort cleanup.
        }
        audioCapture = null
        try {
            recorder?.reset()
        } catch (_: Exception) {
            // The recorder may not have been prepared.
        }
        recorder?.release()
        recorder = null
        virtualDisplay?.release()
        virtualDisplay = null
        try {
            projection?.let { active ->
                projectionCallback?.let(active::unregisterCallback)
                active.stop()
            }
        } catch (_: Exception) {
            // The projection may not have started.
        }
        projection = null
        projectionCallback = null
        videoTempFile?.delete()
        audioTempFile?.delete()
        videoTempFile = null
        audioTempFile = null
    }

    private fun attachOverlay() {
        if (overlayAttached || !android.provider.Settings.canDrawOverlays(this)) return
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(4), dp(4), dp(4))
                setBackgroundColor(Color.argb(235, 22, 31, 42))
            }
            val primary = makeOverlayButton("Start")
            val stop = makeOverlayButton("Stop")
            container.addView(primary, LinearLayout.LayoutParams(dp(78), dp(48)))
            container.addView(stop, LinearLayout.LayoutParams(dp(78), dp(48)).apply {
                leftMargin = dp(3)
            })

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = dp(24)
                y = dp(180)
            }
            installDragAndClick(primary, params) { onPrimaryButton() }
            installDragAndClick(stop, params) { stopRecording() }
            overlay = container
            primaryButton = primary
            stopButton = stop
            overlayParams = params
            windowManager?.addView(container, params)
            overlayAttached = true
            updateOverlay()
        } catch (_: Exception) {
            overlayAttached = false
        }
    }

    private fun makeOverlayButton(label: String): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(21, 101, 192))
            contentDescription = label
        }

    private fun installDragAndClick(
        button: Button,
        params: WindowManager.LayoutParams,
        click: () -> Unit
    ) {
        var downX = 0f
        var downY = 0f
        var originX = 0
        var originY = 0
        var moved = false
        button.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    originX = params.x
                    originY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - downX).toInt()
                    val deltaY = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(deltaX) + kotlin.math.abs(deltaY) > dp(5)) moved = true
                    if (moved) {
                        params.x = (originX + deltaX).coerceAtLeast(0)
                        params.y = (originY + deltaY).coerceAtLeast(0)
                        try {
                            windowManager?.updateViewLayout(overlay, params)
                        } catch (_: Exception) {
                            // Ignore a drag if Android has already removed the overlay window.
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) click()
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    private fun onPrimaryButton() {
        when (state) {
            RecordingState.IDLE -> requestProjectionConsent()
            RecordingState.RECORDING -> pauseRecording()
            RecordingState.PAUSED -> resumeRecording()
            else -> Unit
        }
    }

    private fun updateOverlay() {
        val primary = primaryButton ?: return
        when (state) {
            RecordingState.IDLE -> {
                primary.text = "Start"
                stopButton?.visibility = View.GONE
            }
            RecordingState.STARTING -> {
                primary.text = "Start"
                stopButton?.visibility = View.GONE
            }
            RecordingState.RECORDING -> {
                primary.text = "Pause"
                stopButton?.visibility = View.VISIBLE
            }
            RecordingState.PAUSED -> {
                primary.text = "Resume"
                stopButton?.visibility = View.VISIBLE
            }
            RecordingState.STOPPING -> {
                primary.text = "Stop"
                stopButton?.visibility = View.GONE
            }
        }
    }

    private fun removeOverlay() {
        if (!overlayAttached) return
        try {
            windowManager?.removeView(overlay)
        } catch (_: Exception) {
            // Android may already have detached it.
        }
        overlayAttached = false
        overlay = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Screen recording",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps screen recording active."
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val status = when (state) {
            RecordingState.PAUSED -> "Recording paused"
            RecordingState.RECORDING -> "Recording screen · ${selectedFrameRate} fps"
            RecordingState.STARTING -> "Starting screen recording"
            else -> "Screen recorder ready"
        }
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Screen Recorder")
                .setContentText(status)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Screen Recorder")
                .setContentText(status)
                .setOngoing(true)
                .build()
        }
    }

    private fun updateNotification() {
        if (!notificationActive) return
        val extra = when {
            state == RecordingState.PAUSED -> "Recording paused"
            audioCapture == null -> "Video only · ${selectedFrameRate} fps"
            micGrantedAtStart && audioCapture?.microphoneEnabled == true -> "Mic on · ${selectedFrameRate} fps"
            else -> "Game audio where allowed · ${selectedFrameRate} fps"
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Screen Recorder")
                .setContentText(extra)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build()
        } else buildNotification()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
    }

    private fun stopForegroundIfActive() {
        if (!notificationActive) return
        stopForeground(STOP_FOREGROUND_REMOVE)
        notificationActive = false
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val ACTION_SHOW_OVERLAY = "com.example.screenrecorder.SHOW_OVERLAY"
        const val ACTION_START_RECORDING = "com.example.screenrecorder.START_RECORDING"
        const val ACTION_PROJECTION_GRANTED = "com.example.screenrecorder.PROJECTION_GRANTED"
        const val ACTION_PROJECTION_CANCELLED = "com.example.screenrecorder.PROJECTION_CANCELLED"
        const val ACTION_KEY_F9 = "com.example.screenrecorder.KEY_F9"
        const val ACTION_PAUSE_RECORDING = "com.example.screenrecorder.PAUSE"
        const val ACTION_RESUME_RECORDING = "com.example.screenrecorder.RESUME"
        const val ACTION_STOP_RECORDING = "com.example.screenrecorder.STOP"
        const val ACTION_TOGGLE_MICROPHONE = "com.example.screenrecorder.TOGGLE_MIC"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"

        private const val CHANNEL_ID = "screen_recorder"
        private const val NOTIFICATION_ID = 5101
        private const val VIDEO_BIT_RATE = 16_000_000
    }
}
