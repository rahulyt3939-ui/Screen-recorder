package com.example.screenrecorder

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class RecorderAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val action = when (event.keyCode) {
            KeyEvent.KEYCODE_F9 -> RecorderService.ACTION_KEY_F9
            KeyEvent.KEYCODE_F10 -> RecorderService.ACTION_STOP_RECORDING
            KeyEvent.KEYCODE_F11 -> RecorderService.ACTION_TOGGLE_MICROPHONE
            else -> return super.onKeyEvent(event)
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            startService(Intent(this, RecorderService::class.java).setAction(action))
        }
        return true
    }
}
